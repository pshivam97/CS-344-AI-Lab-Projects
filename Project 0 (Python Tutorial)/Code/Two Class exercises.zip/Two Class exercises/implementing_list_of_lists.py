all_instances = []  # initialize instances to an empty list
data_filename = 'agaricus-lepiota.data'

# write your code here
with open(data_filename,'r') as file_read:
    for each_line in file_read:
        all_instances.append(each_line.strip().split(','))

print('Read', len(all_instances), 'instances from', data_filename)
# we don't want to print all the instances, so we'll just print the first one to verify
print('Entire File :', all_instances)
