def load_attribute_names_and_values(filename):

    entire_file = list()

    with open(filename,'r') as file:
        for line in file:
            entire_file.append(line.strip())

    attribute_names_and_values = []  # this will be a list of dicts
    # your code goes here
    for each_line in entire_file:
        each_line_split = each_line.split(':')
        each_dict = dict()
        each_dict['name'] = each_line_split[0]
        each_dict['values'] = dict()
        each_line_split_values = each_line_split[1].strip().split(',')

        for each_val in each_line_split_values:
            each_val_split = each_val.strip().split('=')
            each_dict['values'][each_val_split[1]] = each_val_split[0]
        attribute_names_and_values.append(each_dict)
    return attribute_names_and_values

attribute_filename = 'agaricus-lepiota.attributes'

# delete 'simple_ml.' in the function call below to test your function
attribute_names_and_values = load_attribute_names_and_values(attribute_filename)
print('Read', len(attribute_names_and_values), 'attribute values from', attribute_filename)
print('First attribute name:', attribute_names_and_values[0]['name'],
      '; values:', attribute_names_and_values[0]['values'])
print("Entire File :- \n",attribute_names_and_values)
